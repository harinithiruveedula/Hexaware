# printimg the digit at one place of a number
num=input("Enter the number: ")
print(num[-1])