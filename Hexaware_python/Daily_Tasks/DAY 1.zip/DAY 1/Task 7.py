# input is radius and calculating the volume of sphere
from math import *
radius=float(input("enter radius:"))
volume=(4/3*pi*radius*radius*radius)
print("the volume of {0} is {1}".format (radius, volume))
