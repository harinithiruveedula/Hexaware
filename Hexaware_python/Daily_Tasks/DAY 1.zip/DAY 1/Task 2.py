# to find area of a cube
side=float(input("Enter the side length of the cube: "))
surface_area=6*(side**2)
print("The surface area is: {0}".format(surface_area))