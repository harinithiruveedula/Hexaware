from math import sqrt


num = int(input("Enter the number: "))


print("The Hex of the number is: {}".format(hex(num)))
print("The Octal of the number is: {}".format(oct(num)))
print("The Square Root of the number is: {:.2f}".format(sqrt(num)))
