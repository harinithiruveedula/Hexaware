# accept the  number in celsius and covert the same in farenheit

temp = float(input("Enter the temperature in Celsius: "))
F = (temp * 9/5) + 32
print("The temperature {0} degree  after converting into Fahrenheit is {1} F".format(temp, F))
